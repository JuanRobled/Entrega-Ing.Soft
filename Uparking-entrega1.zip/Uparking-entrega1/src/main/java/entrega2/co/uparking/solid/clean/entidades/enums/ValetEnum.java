package entrega2.co.uparking.solid.clean.entidades.enums;

public enum ValetEnum {
    DISPONIBLE,
    OCUPADO
}
