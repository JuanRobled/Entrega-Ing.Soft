module entrega1.entrega1 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens entrega1.entrega1 to javafx.fxml;
    exports entrega1.entrega1;
}
